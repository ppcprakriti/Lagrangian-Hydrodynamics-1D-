path1 = '/Users/prakritipalchoudhury/Lagrangian_1D'
path2 = '/Users/prakritipalchoudhury/Lagrangian_1D/CL5_M14_n_3_2'

pathn = '/Users/prakritipalchoudhury/Lagrangian_1D'
